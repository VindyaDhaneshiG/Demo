using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using sAPI.Models;
using sAPI.Contracts;


namespace sAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {

        ISchServices schServices; 
        //private readonly SchDbContext _context;
       // private readonly ISchServices _service;

        public CourseController(ISchServices _schServices)
        {
            schServices = _schServices;
           // _service = service;
            //_context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllCourses()
        {
             try
            {
                var courses = await schServices.GetAllCourses();
                if (courses == null)
                {
                    return NotFound();
                }

                return Ok(courses);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        // // GET All Courses
        // [HttpGet]
        // public ActionResult<IEnumerable<Course>> GetCourses()
        // {
        //     //_context.Courses.ToListAsync()
        //     var items = _service.GetAllCourses(_context.Courses.ToListAsync());
        //     return  items;
        // }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int? courseId)
        {
            if (courseId == null)
            {
                return BadRequest();
            }

            try
            {
                var course = await schServices.GetById(courseId);

                if (course == null)
                {
                    return NotFound();
                }

                return Ok(course);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // // GET Selected Course
        // [HttpGet("{id}")]
        // public ActionResult<Course> GetCourse(int id)
        // {
        //     var item = _service.GetById(_context.Courses.FindAsync(id));

        //     //var cid = await _context.Courses.FindAsync(id);

        //     if (item == null)
        //     {
        //         return NotFound();
        //     }

        //     return Ok(item);
        // }


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCourse([FromBody]Course model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await schServices.UpdateCourse(model);

                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }


        // //PUT: api/Course/5
        // [HttpPut("{id}")]
        // public IActionResult PutCourse(int id, Course course)
        // {
        //     if (id != course.CourseID)
        //     {
        //         return BadRequest();
        //     }
        //     _context.Entry(course).State = EntityState.Modified;
        //     try
        //     {
        //          _service.Add(_context.SaveChangesAsync());
        //     }
        //     catch (DbUpdateConcurrencyException)
        //     {
        //         if (!CourseExists(id))
        //         {
        //             return NotFound();
        //         }
        //         else
        //         {
        //             throw;
        //         }
        //     }
        //     return NoContent();
        // }
        
        [HttpPost]
        // [Route("Register")]
        //POST : /api/Course/Register
        public async Task<IActionResult> Add([FromBody]Course model)
        {
           if (ModelState.IsValid)
            {
                try
                {
                    var postId = await schServices.Add(model);
                    if (postId > 0)
                    {
                        return Ok(postId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }
        }
        return BadRequest();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Remove(int? id)
        {
             int result = 0;

            if (id == null)
            {
                return BadRequest();
            }

            try
            {
                result = await schServices.Remove(id);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {

                return BadRequest();
            }

        }

        // //DELETE: api/Course/5
        // [HttpDelete("{id}")]
        // public ActionResult<Course> DeleteCourse(int id)
        // {
        //     var sid = _service.GetById(_context.Courses.FindAsync(id));

        //     if (sid == null)
        //     {
        //         return NotFound();
        //     }

        //     _service.Remove(_context.Courses.Remove(sid));
        //      _context.SaveChangesAsync();
        //     return sid;

        // }

        // private bool CourseExists(int id)
        // {
        //     return _context.Courses.Any(e => e.CourseID == id);
        // }


    }
}





