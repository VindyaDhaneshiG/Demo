using sAPI.Models;
using System;
using System.Collections.Generic;
using sAPI.Models;
using sAPI.ViewModel;
using System.Linq;
using System.Threading.Tasks;

namespace sAPI.Contracts
{
    

    public interface ISchServices
    {
        
        
        Task<List<CourseViewModel>> GetAllCourses();
        Task<int> Add(Course newItem);
        Task<CourseViewModel> GetById(int? courseId);
        Task<int> Remove(int? id);
        Task UpdateCourse(Course course);
    }
}