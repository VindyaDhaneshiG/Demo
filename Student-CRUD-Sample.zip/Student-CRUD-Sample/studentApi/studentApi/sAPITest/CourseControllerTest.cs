using System;
using Xunit;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using sAPI.Controllers;
using sAPI.Models;
using sAPI.ViewModel;
using sAPI.Contracts;
using sAPI.Services;
using Microsoft.EntityFrameworkCore;
using System.Text;
using FluentAssertions;


namespace sAPITest
{
    public class CourseControllerTest
    {
       
        SchServices _service;
        public static DbContextOptions<SchDbContext> dbContextOptions { get; }

        public static string connectionString = "Server=(localdb)\\mssqllocaldb; Database=StudentDataBase3; Trusted_Connection=True; MultipleActiveResultSets=True;";
        static CourseControllerTest()
        {
          dbContextOptions = new DbContextOptionsBuilder<SchDbContext>()
                .UseSqlServer(connectionString)
                .Options;
        }
        public CourseControllerTest()
        {
            var context = new SchDbContext(dbContextOptions);
            DummyDataDBInitializer db = new DummyDataDBInitializer();
            db.Seed(context);

            _service = new SchServices(context);

        }
        

        [Fact]
        public async void Task_GetCourseById_Return_OkResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var courseId = 2;

            //Act  
            var data = await controller.GetById(courseId);

            //Assert  
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public async void Task_GetCourseById_Return_NotFoundResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var courseId = 3;

            //Act  
            var data = await controller.GetById(courseId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_GetCourseById_Return_BadRequestResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            int? courseId = null;

            //Act  
            var data = await controller.GetById(courseId);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_GetCourseById_MatchResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            int? courseId = 1;

            //Act  
            var data = await controller.GetById(courseId);

            //Assert  
            Assert.IsType<OkObjectResult>(data);

            var okResult = data.Should().BeOfType<OkObjectResult>().Subject;
            var post = okResult.Value.Should().BeAssignableTo<CourseViewModel>().Subject;

            Assert.Equal("CSHARP", post.CourseName);
            Assert.Equal("12/12/2018", post.StartDate);
        }

        [Fact]
        public async void Task_GetCourses_Return_OkResult()
        {
            //Arrange  
            var controller = new CourseController(_service);

            //Act  
            var data = await controller.GetAllCourses();

            //Assert  
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public void Task_GetCourses_Return_BadRequestResult()
        {
            //Arrange  
            var controller = new CourseController(_service);

            //Act  
            var data = controller.GetAllCourses();
            data = null;

            if (data != null)
            
            //Assert
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_GetCourses_MatchResult()
        {
            //Arrange  
            var controller = new CourseController(_service);

            //Act  
            var data = await controller.GetAllCourses();

            //Assert  
            Assert.IsType<OkObjectResult>(data);

            var okResult = data.Should().BeOfType<OkObjectResult>().Subject;
            var post = okResult.Value.Should().BeAssignableTo<List<CourseViewModel>>().Subject;

            Assert.Equal("CSHARP", post[0].CourseName);
            Assert.Equal("12/12/2018", post[0].StartDate);

            Assert.Equal("HND", post[1].CourseName);
            Assert.Equal("11/10/2018", post[1].StartDate);
        }

        [Fact]
        public async void Task_Add_ValidData_Return_OkResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var post = new Course() { CourseName = "CISCO", StartDate = "11/08/2018", EndDate = "11/08/2019"};

            //Act  
            var data = await controller.Add(post);

            //Assert  
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public async void Task_Add_InvalidData_Return_BadRequest()
        {
            //Arrange  
            var controller = new CourseController(_service);
            Course post = new Course() { CourseName = "Test Title More Than 20 Characteres", StartDate = "15/06/2018", EndDate = "12/07/2019" };

            //Act              
            var data = await controller.Add(post);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_Add_ValidData_MatchResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var post = new Course() { CourseName = "AZURE", StartDate = "12/02/2018", EndDate="12/10/2019" };

            //Act  
            var data = await controller.Add(post);

            //Assert  
            Assert.IsType<OkObjectResult>(data);

            var okResult = data.Should().BeOfType<OkObjectResult>().Subject;
            // var result = okResult.Value.Should().BeAssignableTo<PostViewModel>().Subject;  

            Assert.Equal(3, okResult.Value);
        }

        [Fact]
        public async void Task_Update_ValidData_Return_OkResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var courseId = 2;

            //Act  
            var existingPost = await controller.GetById(courseId);
            var okResult = existingPost.Should().BeOfType<OkObjectResult>().Subject;
            var result = okResult.Value.Should().BeAssignableTo<CourseViewModel>().Subject;

            var course = new Course();
            course.CourseName = "HND Updated";
            course.StartDate = result.StartDate;
            course.EndDate = result.EndDate;
           

            var updatedData = await controller.UpdateCourse(course);

            //Assert  
            Assert.IsType<OkResult>(updatedData);
        }

        [Fact]
        public async void Task_Update_InvalidData_Return_BadRequest()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var courseId = 2;

            //Act  
            var existingPost = await controller.GetById(courseId);
            var okResult = existingPost.Should().BeOfType<OkObjectResult>().Subject;
            var result = okResult.Value.Should().BeAssignableTo<CourseViewModel>().Subject;

            var post = new Course();
            post.CourseName = "Test Title More Than 20 Characteres";
            post.StartDate = result.StartDate;
            post.EndDate = result.EndDate;
            

            var data = await controller.UpdateCourse(post);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_Update_InvalidData_Return_NotFound()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var courseId = 2;

            //Act  
            var existingPost = await controller.GetById(courseId);
            var okResult = existingPost.Should().BeOfType<OkObjectResult>().Subject;
            var result = okResult.Value.Should().BeAssignableTo<CourseViewModel>().Subject;

            var post = new Course();
            post.CourseID = 5;
            post.CourseName = "Test Title More Than 20 Characteres";
            post.StartDate = result.StartDate;
            post.EndDate = result.EndDate;
           

            var data = await controller.UpdateCourse(post);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_Delete_Course_Return_OkResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var courseId = 2;

            //Act  
            var data = await controller.Remove(courseId);

            //Assert  
            Assert.IsType<OkResult>(data);
        }

        [Fact]
        public async void Task_Delete_Course_Return_NotFoundResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            var courseId = 5;

            //Act  
            var data = await controller.Remove(courseId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_Delete_Return_BadRequestResult()
        {
            //Arrange  
            var controller = new CourseController(_service);
            int? courseId = null;

            //Act  
            var data = await controller.Remove(courseId);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }
        
    }
}