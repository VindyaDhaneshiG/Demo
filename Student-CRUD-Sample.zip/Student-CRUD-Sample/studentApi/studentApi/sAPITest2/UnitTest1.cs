using System;
using Xunit;

namespace sAPITest2
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
