import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Enrollment } from './enrollment.model';
import { Student } from './student.model';
import { Course } from './course.model';
import {  HttpParams, HttpHeaders } from '@angular/common/http';
import { ConfigComponent } from './config/config.component'; 
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EnrollmentService {
  formData : Enrollment;
  list : Enrollment[];
  liststu:Student[];
  stuData:Student;
  readonly rootURL="https://localhost:5001/api"
  courses:Observable<Course[]>
  newcourses:Course;
  constructor(private http:HttpClient) { }

  // enrollments = [
  //   {eid: 1, edate: "15-08-2019",sid:1 , sname: "Saman Perera",cid:"1",cname:"Bsc Hons in Computer Science",estatus:"Active", cfee: "500000",installments:"1st Installment",installmentspay:"150000"},
  //   {eid: 2, edate: "20-09-2019",sid:2 , sname: "Nimal Silva",cid:"2",cname:"Bsc Hons in Software Engineering",estatus:"Active", cfee: "600000",installments:"2nd Installment",installmentspay:"200000"},

  //   {eid: 3, edate: "27-09-2019",sid:4 , sname: "Ruwan Gunasekara",cid:"4",cname:"Msc in Computer Science",estatus:"Active", cfee: "300000",installments:"3rd Installment",installmentspay:"100000"},
  //   {eid: 4, edate: "12-09-2019",sid:3 , sname: "Kusum Senarathna",cid:"3",cname:"Bsc Hons in Information Technology",estatus:"Inactive", cfee: "500000",installments:"1st Installment",installmentspay:"10000"}
  // ];

  // public getEnrollments():Array<{eid, edate,sid , sname,cid,cname,estatus, cfee,installments,installmentspay}>{
  //   return this.enrollments;
  // }

  // public createEnrollment(enrollment: {eid, edate,sid , sname,cid,cname,estatus, cfee,installments,installmentspay}){
  //   this.enrollments.push(enrollment);
  // }

  // ---
  postEnrollments( formData : Enrollment){
    return this.http.post(this.rootURL+'/Enrollment',formData)
  }
  //  getStudent(id : number)
  //  {
  //   this.http.get(this.rootURL+'/student/'+id)
  //   .toPromise().then(stu =>this.liststu=stu as Student[]);
  //  }

  refreshList(){
  this.http.get(this.rootURL+'/Enrollment')
  .toPromise().then(res => this.list = res as Enrollment[]);
  }
  


  putEnrollment(formData:Enrollment){
  return this.http.put(this.rootURL+'/Enrollment/'+formData.EnrollmentID,formData);
  }

  deleteEnrollment(id : number)
  {
  return this.http.delete(this.rootURL+'/Enrollment/'+id);
  }

  getEnrollment(){

    return this.http.get(this.rootURL+'/Enrollment/');

  }

  AddEnrollment(enr: Enrollment) {

    const headers = new HttpHeaders().set('content-type', 'application/json');
    var body = {
      EnrollmentDate: enr.EnrollmentDate, StudentID: enr.StudentID, StudentName: enr.StudentName, CourseID:enr.CourseID,CourseName:enr.CourseName,
      EnrollmentStatus:enr.EnrollmentStatus,CourseFee:enr.CourseFee,Installments:enr.Installments,InstallmentPaymentAmount:enr.InstallmentPaymentAmount
    }
    console.log(this.rootURL);

    return this.http.post<Enrollment>(this.rootURL + '/enrollment', body, { headers });

  }




}
