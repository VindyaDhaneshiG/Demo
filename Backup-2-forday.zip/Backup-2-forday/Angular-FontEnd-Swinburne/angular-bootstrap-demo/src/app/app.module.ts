import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { StudentComponent } from './student/student.component';
import { StudentListComponent } from './student-list/student-list.component';
import { LecturerComponent } from './lecturer/lecturer.component';
import { LecturerListComponent } from './lecturer-list/lecturer-list.component';
import { CourseComponent } from './course/course.component';
import { CourseListComponent } from './course-list/course-list.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { EnrollmentListComponent } from './enrollment-list/enrollment-list.component';
import { LoginComponent } from './login/login.component';
// import { AdminComponent } from './admin/admin.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
// import { HttpClientModule } from "@angular/common/http";
import { StudentService } from './student.service';
import { LecturerService } from './lecturer.service';
import { CourseService } from './course.service';
import { EnrollmentService } from './enrollment.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';  
import {  
  MatButtonModule, MatMenuModule, MatDatepickerModule,MatNativeDateModule , MatIconModule, MatCardModule, MatSidenavModule,MatFormFieldModule,  
  MatInputModule, MatTooltipModule, MatToolbarModule  
} from '@angular/material';  
import { MatRadioModule } from '@angular/material/radio';
import { ConfigComponent } from './config/config.component';
import { UpdatelecturerComponent } from './updatelecturer/updatelecturer.component';
import { UpdatestudentComponent } from './updatestudent/updatestudent.component';
import { UpdatecourseComponent } from './updatecourse/updatecourse.component';
import { UpdateenrollmentComponent } from './updateenrollment/updateenrollment.component'; 


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,

    HeaderComponent,
    FooterComponent,
    StudentComponent,
    StudentListComponent,
    LecturerComponent,
    LecturerListComponent,
    CourseComponent,
    CourseListComponent,
    EnrollmentComponent,
    EnrollmentListComponent,
    ConfigComponent,
    UpdatelecturerComponent,
    UpdatestudentComponent,
    UpdatecourseComponent,
    UpdateenrollmentComponent,
    // LoginComponent,
    // AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    HttpClientModule,
    BrowserAnimationsModule,      
    MatButtonModule,  
    MatMenuModule,  
    MatDatepickerModule,  
    MatNativeDateModule,  
    MatIconModule,  
    MatRadioModule,  
    MatCardModule,  
    MatSidenavModule,  
    MatFormFieldModule,  
    MatInputModule,  
    MatTooltipModule,  
    MatToolbarModule 
  ],
  providers: [HttpClientModule,StudentService,LecturerService,CourseService,EnrollmentService,MatDatepickerModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
