import { Component, OnInit ,ViewChild} from '@angular/core';
import { CourseService } from '../course.service';
import { Course} from 'src/app/course.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { CourseComponent } from 'src/app/course/course.component';
import { UpdatecourseComponent } from 'src/app/updatecourse/updatecourse.component';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  courses;
  selectedCourse;
  crslist: Course[];
  dataavailbale: Boolean = false;
  tempcrs: Course
  alldatas: object;

  constructor(public courseService:CourseService,private toastr: ToastrService,private route: Router) { }

  ngOnInit() {
    this.courseService.getCourse().subscribe(res=> {
      this.alldatas = res;
      console.log(this.alldatas);
       });
    this.courseService.refreshList();
  }
  public selectCourse(course){
    this.selectedCourse = course ;
  }

  populateForm(crs:Course){
    this.courseService.formData = Object.assign({},crs);

}

onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.courseService.deleteCourse(id).subscribe(res=>{
     this.courseService.refreshList();
       this.toastr.warning('Deleted Sucessfully','Swinburne University')
   });}
 }

}
