import { Component, OnInit } from '@angular/core';
import { LecturerService } from '../lecturer.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Lecturer } from '../lecturer.model';
@Component({
  selector: 'app-lecturer',
  templateUrl: './lecturer.component.html',
  styleUrls: ['./lecturer.component.css']
})
export class LecturerComponent implements OnInit {
  @Input()  cleardata: boolean = false;
  @Output() nameEvent = new EventEmitter<string>();
  objtleclec:Lecturer;
  @Input() objlec :Lecturer=new Lecturer();
  // @ViewChild('closeBtn') cb: ElementRef;
  // lecturer : {id,fname, lname,dob,doj,email,gender, address,category,contract,qualification} = {id :null, fname:" ", lname :" ",dob:" ",doj:" ",email:" ",gender:" ", address:" ",category:" ",contract:" ",qualification:" "};
  constructor(private service: LecturerService,private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }
  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        LecturerID: null,
        FirstName:'',
        LastName:'',
        DateofBirth:'',
        DateofJoin:'',
        ContactEmail:'',
        Gender:'',
        ContactAddress:'',
        LecturerCategory:'',
        LecturerContract:'',
        LecturerQualification:''

       }
       }
       onSubmit(form : NgForm) {
        // if(form.value.LecturerID==null)
        this.insertRecord(form);
        // else
        // this.updateRecord(form);
      }
      insertRecord(form : NgForm){
       this.service.postLecturer(form.value).subscribe(res=> {
       this.toastr.success('Inserted Sucessfully','Swinburne Register')
      this.resetForm(form);
      this.service.refreshList();
       });
      }

      Register(lecadd:NgForm){  
   
        this.objtleclec=new Lecturer();
        this.objtleclec.FirstName=lecadd.value.firstName;
        this.objtleclec.LastName=lecadd.value.lastName;
        this.objtleclec.DateofBirth=lecadd.value.dateofBirth;
        this.objtleclec.DateofJoin=lecadd.value.dateofJoin;
        this.objtleclec.ContactEmail=lecadd.value.contactEmail;
        this.objtleclec.ContactEmail=lecadd.value.Gender;
        this.objtleclec.ContactAddress=lecadd.value.ContactAddress;
        this.objtleclec.LecturerCategory=lecadd.value.LecturerCategory;
        this.objtleclec.LecturerContract=lecadd.value.LecturerContract;
        this.objtleclec.LecturerQualification=lecadd.value.lecturerQualification;

        
      this.service.AddLecturer(this.objtleclec).subscribe(res=>{
        alert("Lecturer Added successfully");
        // this.TakeHome();
        // this.lecadd.objtleclec.FirstName = ""
    }
  )}
      updateRecord(form:NgForm){
        this.service.putLecturer(form.value).subscribe(res=> {
          this.toastr.warning('Updated Sucessfully','Swinburn Register')
          this.resetForm(form);
          this.service.refreshList();
           });
      
      }



}
