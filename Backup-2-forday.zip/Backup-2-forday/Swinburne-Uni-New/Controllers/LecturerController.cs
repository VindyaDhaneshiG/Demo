using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Swinburne_Uni_New.Models;

namespace Swinburne_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class LecturerController : ControllerBase
    {
        private readonly SwinburneContext _context;
        public LecturerController(SwinburneContext context)
        {

            _context = context;
        }

        // GET All Lecturer
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Lecturer>>> GetLecturers()
        {
            return await _context.Lecturers.ToListAsync();
        }
        // GET Selected Student
        [HttpGet("{id}")]
        public async Task<ActionResult<Lecturer>> GetLecturer(int id)
        {
            var lid = await _context.Lecturers.FindAsync(id);

            if (lid == null)
            {
                return NotFound();
            }

            return lid;
        }
        [HttpPost]
        public async Task<ActionResult<Lecturer>> PostLecturer(Lecturer lecturer)
        {
            _context.Lecturers.Add(lecturer);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLecturer", new { id = lecturer.LecturerID }, lecturer);
        }  
///
//Get action methods of the previous section
//     [HttpPost]
//     public ActionResult PostNewLecturer(Lecturer lecturer)
//     {
//         if (!ModelState.IsValid)
//             return BadRequest("Invalid data.");

//         using (var ctx = new SwinburneContext())
//         {
//             ctx.Lecturers.Add(new Lecturer()
//             {
//                 LecturerID = lecturer.LecturerID,
//                 FirstName = lecturer.FirstName,
//                 LastName = lecturer.LastName,
//                 DateofBirth=lecturer.LastName,
//                 DateofJoin=lecturer.DateofJoin,
//                 ContactEmail=lecturer.ContactEmail,
//                 Gender=lecturer.Gender,
//                 ContactAddress=lecturer.ContactAddress,
//                 LecturerCategory=lecturer.LecturerCategory,
//                 LecturerContract=lecturer.LecturerCategory,
//                 LecturerQualification=lecturer.LecturerQualification
//             });

//             ctx.SaveChanges();
//         }

//         return Ok();
//     }
// } 

        [HttpPut("{id}")]
        public async Task<IActionResult> PutLecturer(int id, Lecturer lecturer)
        {
            if (id != lecturer.LecturerID)
            {
                return BadRequest();
            }
            _context.Entry(lecturer).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LecturerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    return NotFound();
                }
            }
            return NoContent();
        }

        private bool LecturerExists(int id)
        {
            return _context.Lecturers.Any(l => l.LecturerID == id);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Lecturer>> DeleteLecturer(int id)
        {
            var lid = await _context.Lecturers.FindAsync(id);

            if (lid == null)
            {
                return NotFound();
            }

            _context.Lecturers.Remove(lid);
            await _context.SaveChangesAsync();
            return lid;

        }

    }
}


