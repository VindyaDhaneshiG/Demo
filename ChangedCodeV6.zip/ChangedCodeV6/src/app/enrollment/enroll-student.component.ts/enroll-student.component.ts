import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { EnrollmentService } from '../shared/services/enrollment.service';
import { CourseService } from 'src/app/course/shared/services/course.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Enrollment } from '../shared/models/enrollment.model';
import { ToastrService } from 'ngx-toastr';
import { StudentService } from 'src/app/student/shared/services/student.service';
import { Student } from 'src/app/student/shared/models/student.model';

@Component({
  selector: 'app-enroll-student',
  templateUrl: './enroll-student.component.html',
  styleUrls: ['./enroll-student.component.css']
})
export class EnrollStudentComponent implements OnInit {

  enrollmentForm: FormGroup;
  courseList: object;
  enrollList: object;
  studentName: string;
  studentIdNumber: number;

  constructor(private service: StudentService, private enrollService: EnrollmentService,
    private courseService: CourseService, private toastr: ToastrService,
    private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.formLoad();
  }

  formLoad() {
    this.activatedRoute.queryParams.subscribe((params: any) => {

      if (params.id) {
        this.studentIdNumber = Number.parseInt(params.id, 10);
      }
    });

    this.enrollmentForm = new FormGroup({
      courseID: new FormControl('', [Validators.required]),
      enrolledDate: new FormControl('', [Validators.required])
    });

    this.enrollmentForm.reset();
    this.getRecord(this.studentIdNumber);

  }
  getRecord(id: number) {
    this.service.GetStudent(id).subscribe((res: any) => {
      this.studentName = `${res.firstName} ${res.lastName}`;

      this.enrollService.getEnrollmentByStudentId(id).subscribe(enroll => {
        this.enrollList = enroll;
      });
    });

    this.courseService.getCourseList().subscribe(courses => {
      console.log('ssssssssssssss');
      console.log(courses);
      this.courseList = courses;
    });

  }


  onEnrollmentSubmit() {
    const enroll = this.RegisterEnrollment();

    this.enrollService.postEnrollments(enroll).subscribe(res => {
      // Todo: Needs to update on the toast message
      this.toastr.success('Updated Sucessfully', 'Swinburne Register');
      this.formLoad();
    });
  }

  RegisterEnrollment(): Enrollment {
    const enroll = new Enrollment();
    console.log(this.enrollmentForm);
    enroll.CourseID = Number.parseInt(this.enrollmentForm.value.courseID, 10);
    enroll.EnrollmentDate = this.enrollmentForm.value.enrolledDate;
    enroll.StudentID = this.studentIdNumber;
    enroll.EnrollmentStatus = 'Enrolled';

    console.log(enroll);
    return enroll;
  }

  deleteEnrollment(enrollmentId) {
    if (confirm('Are you sure to delete this record?')) {
      this.enrollService.deleteEnrollment(enrollmentId).subscribe(res => {
        this.toastr.success('Deleted Sucessfully', 'Swinburne Register');
        this.formLoad();
      });
    }
  }

  back() {
    this.router.navigate(['students/update'], { queryParams: { id: this.studentIdNumber } });
  }
}
