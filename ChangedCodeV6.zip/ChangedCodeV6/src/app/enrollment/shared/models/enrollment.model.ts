export class Enrollment {
    EnrollmentID: number;
    EnrollmentDate: string;
    StudentID: number;
    CourseID: number;
    EnrollmentStatus: string;

}
