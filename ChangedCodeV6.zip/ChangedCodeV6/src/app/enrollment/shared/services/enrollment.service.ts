import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Enrollment } from '../models/enrollment.model';
import { Student } from '../../../student/shared/models/student.model';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import { ConfigComponent } from '../../../config/config.component';
import { Observable } from 'rxjs';
import { Course } from '../../../course/shared/models/course.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EnrollmentService {
  private readonly apiPath = '/Enrollment';
  private readonly urlDetails = `${environment.studentApiUrl}${this.apiPath}`;

  constructor(private http: HttpClient) { }

  postEnrollments(formData: Enrollment) {
    return this.http.post(this.urlDetails, formData);
  }

  putEnrollment(formData: Enrollment) {
    return this.http.put(`${this.urlDetails}/${formData.EnrollmentID}`, formData);
  }

  deleteEnrollment(id: number) {
    return this.http.delete(`${this.urlDetails}/${id}`);
  }

  getEnrollmentByStudentId(sid: number) {
    const id = this.http.get(`${this.urlDetails}?Student=${sid}`);
    console.log(id);
    return id;
  }

  getEnrollmentByCourseId(cid: number) {
    return this.http.get(`${this.urlDetails}?Course/${cid}`);
  }

}
