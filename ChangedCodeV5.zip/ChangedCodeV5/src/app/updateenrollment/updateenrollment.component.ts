import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateenrollment',
  templateUrl: './updateenrollment.component.html',
  styleUrls: ['./updateenrollment.component.css']
})
export class UpdateenrollmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
