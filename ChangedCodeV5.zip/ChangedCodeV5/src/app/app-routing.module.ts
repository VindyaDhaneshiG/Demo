import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { AuthGuard } from './auth.guard';
import { HomeComponent } from './home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StudentCreateComponent } from './student/student-create/student-create.component';
import { StudentComponent } from './student/student.component';
import { CourseCreateComponent } from './course/course-create/course-create.component';
import { CourseComponent } from './course/course.component';
import { LecturerCreateComponent } from './lecturer/lecturer-create/lecturer-create.component';
import { EnrollmentListComponent } from './enrollment-list/enrollment-list.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { LoginComponent } from './login/login.component';
// import { AdminComponent } from './admin/admin.component';
import { StudentUpdateComponent } from './student/student-update/student-update.component';
import { LecturerUpdateComponent } from './lecturer/lecturer-update/lecturer-update.component';
import { LecturerComponent } from './lecturer/lecturer.component';
import { CourseUpdateComponent } from './course/course-update/course-update.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'students/update', component: StudentUpdateComponent },
  { path: 'students/create', component: StudentCreateComponent },
  { path: 'students', component: StudentComponent },
  { path: 'lecturers', component: LecturerComponent },
  { path: 'lecturers/create', component: LecturerCreateComponent },
  { path: 'lecturers/update', component: LecturerUpdateComponent },
  { path: 'courses', component: CourseComponent },
  { path: 'courses/create', component: CourseCreateComponent },
  { path: 'courses/update', component: CourseUpdateComponent },
  // { path: 'enrollment', component: EnrollmentComponent },
  // { path: 'enrollment-list', component: EnrollmentListComponent },
  // { path: 'updatelecturer', component: UpdatelecturerComponent },
  // { path: 'updatecourse', component: UpdatecourseComponent },
  // { path: 'updateenrollment', component: UpdateenrollmentComponent },

  // { path: 'admin', component: AdminComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
