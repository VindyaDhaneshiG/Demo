import { Component, OnInit, ViewChild } from '@angular/core';
import { EnrollmentService } from '../enrollment.service';
import { Enrollment } from 'src/app/enrollment.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { EnrollmentComponent } from 'src/app/enrollment/enrollment.component';
import { UpdateenrollmentComponent } from 'src/app/updateenrollment/updateenrollment.component';
@Component({
  selector: 'app-enrollment-list',
  templateUrl: './enrollment-list.component.html',
  styleUrls: ['./enrollment-list.component.css']
})
export class EnrollmentListComponent implements OnInit {
  enrollments;
  selectedEnrollment;

  leclist: Enrollment[];
  dataavailbale: Boolean = false;
  tempenr: Enrollment
  alldatas: object;
  constructor(public enrollmentService: EnrollmentService, private toastr: ToastrService, private route: Router) { }

  ngOnInit() {
    this.enrollmentService.getEnrollment().subscribe(res => {
      this.alldatas = res;
      //console.log(this.alldatas);
    });
    this.enrollmentService.refreshList();
  }
  public selectEnrollment(enrollment) {
    this.selectedEnrollment = enrollment;
  }

  populateForm(lec: Enrollment) {
    this.enrollmentService.formData = Object.assign({}, lec);

  }

  onDelete(id: number) {
    if (confirm("Are you sure to delete this record?")) {
      this.enrollmentService.deleteEnrollment(id).subscribe(res => {
        this.enrollmentService.refreshList();
        this.toastr.warning('Deleted Sucessfully', 'Swinburne University')
      });
    }
  }




}
