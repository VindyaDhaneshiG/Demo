using Swinburne_Uni_New.Models;
using System;
using System.Collections.Generic;

using Swinburne_Uni_New.ViewModel;
using System.Linq;
using System.Threading.Tasks;

namespace Swinburne_Uni_New.Contracts
{
    

    public interface ISchServices2
    {
        
        
        Task<List<StudentViewModel>> GetAllStudents();
        Task<int> Add(Student newItem);
        Task<StudentViewModel> GetById(int? studentId);
        Task<int> Remove(int? id);
        Task UpdateStudent(Student student);
    }
}