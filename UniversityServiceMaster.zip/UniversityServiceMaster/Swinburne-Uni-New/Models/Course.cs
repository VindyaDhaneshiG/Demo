using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;


namespace Swinburne_Uni_New.Models
{
    public class Course 
    {
        [Key]
        public int CourseID { get; set; }
        
        [Column(TypeName = "varchar(20)")]
        [Required]
        public string CourseName { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }


         public virtual ICollection<Enrollment> Enrollments { get; set; }
        
    }
}
