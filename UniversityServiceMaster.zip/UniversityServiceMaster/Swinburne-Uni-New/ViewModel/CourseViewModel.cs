namespace Swinburne_Uni_New.ViewModel
{
    public class CourseViewModel
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}