using Swinburne_Uni_New.Models;
using System;
using System.Collections.Generic;
using Swinburne_Uni_New.Contracts;
using Swinburne_Uni_New.ViewModel;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Swinburne_Uni_New.Services
{
    public class SchServices2 : ISchServices2
    {
        SchDbContext db;

        public SchServices2(SchDbContext _db)
        {
            db = _db;
        }

         public async Task<int> Add (Student newItem)
        {
           if (db != null)
            {
                await db.Students.AddAsync(newItem);
                await db.SaveChangesAsync();

                return newItem.StudentID;
            }

            return 0;
        }

        public async Task<List<StudentViewModel>>  GetAllStudents()
        {
           if (db != null)
            {
                return await (from s in db.Students
                              
                              select new StudentViewModel
                              {
                                  StudentID = s.StudentID,
                                  FirstName = s.FirstName,
                                  MiddleName = s.MiddleName,
                                  LastName = s.LastName,
                                  Mobile=s.Mobile,
                                  Telephone=s.Telephone,
                                  Email=s.Email,
                                  Address=s.Address,
                                  DOB=s.DOB,
                                  NIC=s.NIC
        
                                  
                              }).ToListAsync();
            }

            return null;
        }

        public async Task<StudentViewModel> GetById(int? studentId)
        {
            if (db != null){

                    return await (from s in db.Students
                              
                              where s.StudentID == studentId
                              select new StudentViewModel
                              {
                                  StudentID = s.StudentID,
                                  FirstName = s.FirstName,
                                  MiddleName = s.MiddleName,
                                  LastName = s.LastName,
                                  Mobile=s.Mobile,
                                  Telephone=s.Telephone,
                                  Email=s.Email,
                                  Address=s.Address,
                                  DOB=s.DOB,
                                  NIC=s.NIC
                              }).FirstOrDefaultAsync();
                }


           return null;
        }

        public async Task<int>  Remove(int? id)
        {
            int result = 0;

            if (db != null)
            {
                //Find the post for specific post id
                var student = await db.Students.FirstOrDefaultAsync(x => x.StudentID == id);

                if (student != null)
                {
                    //Delete that post
                    db.Students.Remove(student);

                    //Commit the transaction
                    result = await db.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }

         public async Task UpdateStudent(Student student)
        {
            if (db != null)
            {
                //Delete that post
                db.Students.Update(student);

                //Commit the transaction
                await db.SaveChangesAsync();
            }
        }
        
    }
}