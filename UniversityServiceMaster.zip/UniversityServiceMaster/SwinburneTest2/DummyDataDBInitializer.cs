using Swinburne_Uni_New.Models;
using System;

namespace SwinburneTest2
{
    public class DummyDataDBInitializer
    {
        public DummyDataDBInitializer()
        {
        }

        public void Seed(SchDbContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Students.AddRange(
                new Student() { FirstName = "Lasanka", MiddleName = "Geethani", LastName = "Dharmasiri",Mobile="071243456",Telephone="011256789",Email="sam@gmail.com,",Address="No7,Flowers lane,Dehiwala",DOB="12/07/2019",NIC="92345678V" },
                new Student() { FirstName = "Mahesha", MiddleName = "Thejani", LastName = "Dharmasiri",Mobile="071243456",Telephone="011256789",Email="sam@gmail.com,",Address="No7,Flowers lane,Dehiwala",DOB="12/07/2019",NIC="95345678V" }
            );

            
            context.SaveChanges();
        }
    }
}