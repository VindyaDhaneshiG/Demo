using System;
using Xunit;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Swinburne_Uni_New.Controllers;
using Swinburne_Uni_New.Models;
using Swinburne_Uni_New.ViewModel;
using Swinburne_Uni_New.Contracts;
using Swinburne_Uni_New.Services;
using Microsoft.EntityFrameworkCore;
using System.Text;
using FluentAssertions;


namespace SwinburneTest2
{
    public class StudentControllerTest
    {
       
        SchServices2 _service;
        public static DbContextOptions<SchDbContext> dbContextOptions { get; }

        public static string connectionString = "Server=(localdb)\\mssqllocaldb; Database=StudentDataBase3; Trusted_Connection=True; MultipleActiveResultSets=True;";
        static StudentControllerTest()
        {
          dbContextOptions = new DbContextOptionsBuilder<SchDbContext>()
                .UseSqlServer(connectionString)
                .Options;
        }
        public StudentControllerTest()
        {
            var context = new SchDbContext(dbContextOptions);
            DummyDataDBInitializer db = new DummyDataDBInitializer();
            db.Seed(context);

            _service = new SchServices2(context);

        }
        

        [Fact]
        public async void Task_GetCourseById_Return_OkResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var studentId = 2;

            //Act  
            var data = await controller.GetById(studentId);

            //Assert  
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public async void Task_GetStudentById_Return_NotFoundResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var studentId = 3;

            //Act  
            var data = await controller.GetById(studentId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_GetCourseById_Return_BadRequestResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            int? studentId = null;

            //Act  
            var data = await controller.GetById(studentId);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_GetCourseById_MatchResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            int? studentId = 1;

            //Act  
            var data = await controller.GetById(studentId);

            //Assert  
            Assert.IsType<OkObjectResult>(data);

            var okResult = data.Should().BeOfType<OkObjectResult>().Subject;
            var post = okResult.Value.Should().BeAssignableTo<StudentViewModel>().Subject;

            Assert.Equal("Lasanka", post.FirstName);
            Assert.Equal("12/12/2018", post.DOB);
        }

        [Fact]
        public async void Task_GetCourses_Return_OkResult()
        {
            //Arrange  
            var controller = new StudentController(_service);

            //Act  
            var data = await controller.GetAllStudents();

            //Assert  
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public void Task_GetStudents_Return_BadRequestResult()
        {
            //Arrange  
            var controller = new StudentController(_service);

            //Act  
            var data = controller.GetAllStudents();
            data = null;

            if (data != null)
            
            //Assert
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_GetStudents_MatchResult()
        {
            //Arrange  
            var controller = new StudentController(_service);

            //Act  
            var data = await controller.GetAllStudents();

            //Assert  
            Assert.IsType<OkObjectResult>(data);

            var okResult = data.Should().BeOfType<OkObjectResult>().Subject;
            var post = okResult.Value.Should().BeAssignableTo<List<StudentViewModel>>().Subject;

            Assert.Equal("Lasanka", post[0].FirstName);
            Assert.Equal("12/12/2018", post[0].DOB);

            Assert.Equal("Kamal", post[1].FirstName);
            Assert.Equal("11/10/2018", post[1].DOB);
        }

        [Fact]
        public async void Task_Add_ValidData_Return_OkResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var post = new Student() { FirstName = "Lasanka", MiddleName = "Geethani", LastName = "Dharmasiri",Mobile="071243456",Telephone="011256789",Email="sam@gmail.com,",Address="No7,Flowers lane,Dehiwala",DOB="12/07/2019",NIC="92345678V"};

            //Act  
            var data = await controller.Add(post);

            //Assert  
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public async void Task_Add_InvalidData_Return_BadRequest()
        {
            //Arrange  
            var controller = new StudentController(_service);
            Student post = new Student() { FirstName = "Lasanka", MiddleName = "Geethani", LastName = "Dharmasiri",Mobile="071243456",Telephone="011256789",Email="sam@gmail.com,",Address="No7,Flowers lane,Dehiwala",DOB="12/07/2019",NIC="92345678V" };

            //Act              
            var data = await controller.Add(post);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_Add_ValidData_MatchResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var post = new Student() {  FirstName = "Lasanka", MiddleName = "Geethani", LastName = "Dharmasiri",Mobile="071243456",Telephone="011256789",Email="sam@gmail.com,",Address="No7,Flowers lane,Dehiwala",DOB="12/07/2019",NIC="92345678V" };

            //Act  
            var data = await controller.Add(post);

            //Assert  
            Assert.IsType<OkObjectResult>(data);

            var okResult = data.Should().BeOfType<OkObjectResult>().Subject;
            // var result = okResult.Value.Should().BeAssignableTo<PostViewModel>().Subject;  

            Assert.Equal(3, okResult.Value);
        }

        [Fact]
        public async void Task_Update_ValidData_Return_OkResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var studentId = 2;

            //Act  
            var existingPost = await controller.GetById(studentId);
            var okResult = existingPost.Should().BeOfType<OkObjectResult>().Subject;
            var result = okResult.Value.Should().BeAssignableTo<StudentViewModel>().Subject;

            var student = new Student();
            student.FirstName = "Student Name Updated";
            student.MiddleName = result.MiddleName;
            student.LastName = result.LastName;
            student.Mobile=result.Mobile;
            student.Telephone=result.Telephone;
            student.Email=result.Email;
            student.Address=result.Address;
            student.DOB=result.DOB;
            student.NIC=result.NIC;

            var updatedData = await controller.UpdateStudent(student);

            //Assert  
            Assert.IsType<OkResult>(updatedData);
        }

        [Fact]
        public async void Task_Update_InvalidData_Return_BadRequest()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var studentId = 2;

            //Act  
            var existingPost = await controller.GetById(studentId);
            var okResult = existingPost.Should().BeOfType<OkObjectResult>().Subject;
            var result = okResult.Value.Should().BeAssignableTo<StudentViewModel>().Subject;

            var post = new Student();
            post.FirstName = "Test Title More Than 20 Characteres";
            post.MiddleName = result.MiddleName;
            post.LastName = result.LastName;
            post.Mobile=result.Mobile;
            post.Telephone=result.Telephone;
            post.Email=result.Email;
            post.Address=result.Address;
            post.DOB=result.DOB;
            post.NIC=result.NIC;

            var data = await controller.UpdateStudent(post);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }

        [Fact]
        public async void Task_Update_InvalidData_Return_NotFound()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var studentId = 2;

            //Act  
            var existingPost = await controller.GetById(studentId);
            var okResult = existingPost.Should().BeOfType<OkObjectResult>().Subject;
            var result = okResult.Value.Should().BeAssignableTo<StudentViewModel>().Subject;

            var post = new Student();
           post.FirstName = "Test Title More Than 20 Characteres";
            post.MiddleName = result.MiddleName;
            post.LastName = result.LastName;
            post.Mobile=result.Mobile;
            post.Telephone=result.Telephone;
            post.Email=result.Email;
            post.Address=result.Address;
            post.DOB=result.DOB;
            post.NIC=result.NIC;
           

            var data = await controller.UpdateStudent(post);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_Delete_Student_Return_OkResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var studentId = 2;

            //Act  
            var data = await controller.Remove(studentId);

            //Assert  
            Assert.IsType<OkResult>(data);
        }

        [Fact]
        public async void Task_Delete_Student_Return_NotFoundResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            var studentId = 5;

            //Act  
            var data = await controller.Remove(studentId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_Delete_Return_BadRequestResult()
        {
            //Arrange  
            var controller = new StudentController(_service);
            int? studentId = null;

            //Act  
            var data = await controller.Remove(studentId);

            //Assert  
            Assert.IsType<BadRequestResult>(data);
        }
        
    }
}