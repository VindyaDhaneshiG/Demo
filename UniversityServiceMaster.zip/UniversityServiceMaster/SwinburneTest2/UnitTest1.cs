using System;
using Xunit;

namespace SwinburneTest2
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
