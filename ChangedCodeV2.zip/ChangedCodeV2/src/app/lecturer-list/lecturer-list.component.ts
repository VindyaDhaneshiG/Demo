import { Component, OnInit,ViewChild } from '@angular/core';
import { LecturerService } from 'src/app/lecturer.service';
import { Lecturer} from 'src/app/lecturer.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { LecturerComponent } from 'src/app/lecturer/lecturer.component';
import { UpdatelecturerComponent } from 'src/app/updatelecturer/updatelecturer.component';
@Component({
  selector: 'app-lecturer-list',
  templateUrl: './lecturer-list.component.html',
  styleUrls: ['./lecturer-list.component.css']
})

export class LecturerListComponent implements OnInit {
  lecturers;
  selectedLecturer;
  leclist: Lecturer[];
  dataavailbale: Boolean = false;
  templec: Lecturer
  alldatas: object;
  constructor(public lecturerService:LecturerService,private toastr: ToastrService,private route: Router) { }

  ngOnInit() {
    this.lecturerService.getLecturer().subscribe(res=> {
      this.alldatas = res;
      console.log(this.alldatas);
       });
    this.lecturerService.refreshList();
    // this.LoadData();
  }
  
  // @ViewChild('lecadd') addcomponent: LecturerComponent
  // @ViewChild('Lecedit') editcomponent: UpdatelecturerComponent

  public selectLecturer(lecturer){
    this.selectedLecturer = lecturer ;
  }
  
  populateForm(lec:Lecturer){
    this.lecturerService.formData = Object.assign({},lec);

 }

 onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.lecturerService.deleteLecturer(id).subscribe(res=>{
     this.lecturerService.refreshList();
       this.toastr.warning('Deleted Sucessfully','Swinburne University')
   });}
 }

//  loadnewForm(LecturerID: number, FirstName: string, LastName: string, DateofBirth: string, DateofJoin: string,ContactEmail:string,Gender:string,ContactAddress:string,LecturerCategory:string,LecturerContract:string,LecturerQualification:string) {
  
  
//   this.editcomponent.templec.LecturerID = LecturerID
//   this.editcomponent.templec.FirstName = FirstName
//   this.editcomponent.templec.LastName = LastName
//   this.editcomponent.templec.DateofBirth = DateofBirth
//   this.editcomponent.templec.DateofJoin = DateofJoin
//   this.editcomponent.templec.ContactEmail = ContactEmail
//   this.editcomponent.templec.Gender = Gender
//   this.editcomponent.templec.ContactAddress = ContactAddress
//   this.editcomponent.templec.LecturerCategory = LecturerCategory
//   this.editcomponent.templec.LecturerContract = LecturerContract
//   this.editcomponent.templec.LecturerQualification = LecturerQualification
  

// }

}
