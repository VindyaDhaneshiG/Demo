import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { AuthGuard } from './auth.guard';
import { HomeComponent } from './home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StudentCreateComponent } from './student/student-create/student-create.component';
import { StudentComponent } from './student/student.component';
import { CourseComponent } from './course/course.component';
import { CourseListComponent } from './course-list/course-list.component';
import { LecturerComponent } from './lecturer/lecturer.component';
import { LecturerListComponent } from './lecturer-list/lecturer-list.component';
import { EnrollmentListComponent } from './enrollment-list/enrollment-list.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { LoginComponent } from './login/login.component';
// import { AdminComponent } from './admin/admin.component';
import { UpdatelecturerComponent } from './updatelecturer/updatelecturer.component';
import { StudentUpdateComponent } from './student/student-update/student-update.component';
import { UpdatecourseComponent } from './updatecourse/updatecourse.component';
import { UpdateenrollmentComponent } from './updateenrollment/updateenrollment.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'students/update', component: StudentUpdateComponent },
  { path: 'students/create', component: StudentCreateComponent },
  { path: 'students', component: StudentComponent },
  // { path: 'lecturer', component: LecturerComponent },
  // { path: 'lecturer-list', component: LecturerListComponent },
  // { path: 'course', component: CourseComponent },
  // { path: 'course-list', component: CourseListComponent },
  // { path: 'enrollment', component: EnrollmentComponent },
  // { path: 'enrollment-list', component: EnrollmentListComponent },
  // { path: 'updatelecturer', component: UpdatelecturerComponent },
  // { path: 'updatecourse', component: UpdatecourseComponent },
  // { path: 'updateenrollment', component: UpdateenrollmentComponent },

  // { path: 'admin', component: AdminComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
