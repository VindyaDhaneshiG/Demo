import { Component, OnInit } from '@angular/core';
import { EnrollmentService } from '../enrollment.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Enrollment } from '../enrollment.model';
@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css']
})
export class EnrollmentComponent implements OnInit {
  @Input()  cleardata: boolean = false;
  @Output() nameEvent = new EventEmitter<string>();
  objtenrenr:Enrollment;
  @Input() objenr :Enrollment=new Enrollment();
  // @ViewChild('closeBtn') cb: ElementRef;
  // lecturer : {eid,edate, sid,sname,cid,cname,estatus,cfee, installments,installmentspay} = {eid :null, edate:"", sid :" ",sname:" ",cid:" ", cname:"",estatus:" ",cfee:" ", installments:" ",installmentspay:" "};
  constructor(private service: EnrollmentService,private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        EnrollmentID: null,
        EnrollmentDate:'',
        StudentID: null,
        StudentName:'',
        CourseID: null,
        CourseName:'',
        EnrollmentStatus:'',
        CourseFee: null,
        Installments:'',
        InstallmentPaymentAmount: null
        

       }
       }
       onSubmit(form : NgForm) {
        // if(form.value.LecturerID==null)
        this.insertRecord(form);
        // else
        // this.updateRecord(form);
      }

      insertRecord(form : NgForm){
        this.service.postEnrollments(form.value).subscribe(res=> {
        this.toastr.success('Inserted Sucessfully','Swinburne Register')
       this.resetForm(form);
       this.service.refreshList();
        });
       }
       Register(enradd:NgForm){  
   
        this.objtenrenr=new Enrollment();
        this.objtenrenr.EnrollmentDate=enradd.value.enrollmentDate;
        this.objtenrenr.StudentID=enradd.value.studentID;
        this.objtenrenr.StudentName=enradd.value.studentName;
        this.objtenrenr.CourseID=enradd.value.courseID;
        this.objtenrenr.CourseName=enradd.value.courseName;
        this.objtenrenr.EnrollmentStatus=enradd.value.enrollmentStatus;
        this.objtenrenr.CourseFee=enradd.value.courseFee;
        this.objtenrenr.Installments=enradd.value.installments;
        this.objtenrenr.InstallmentPaymentAmount=enradd.value.InstallmentPaymentAmount;
        

        
      this.service.AddEnrollment(this.objtenrenr).subscribe(res=>{
        alert("Enrollment Added successfully");
        // this.TakeHome();
        // this.lecadd.objtleclec.FirstName = ""
    }
  )}

  updateRecord(form:NgForm){
    this.service.postEnrollments(form.value).subscribe(res=> {
      this.toastr.warning('Updated Sucessfully','Swinburn Register')
      this.resetForm(form);
      this.service.refreshList();
       });
  
  }

}
