import { Lecturer } from './lecturer.model';

describe('Lecturer', () => {
  it('should create an instance', () => {
    expect(new Lecturer()).toBeTruthy();
  });
});
