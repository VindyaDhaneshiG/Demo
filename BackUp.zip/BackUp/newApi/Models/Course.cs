using System;  
using System.Collections.Generic;  
using System.ComponentModel.DataAnnotations;  
using System.Linq;  
using System.Threading.Tasks;  
  

namespace newApi.Models
{
    public class Course
    {
        [Key]
        public int CourseID {get;set;}
        
        public string CourseName {get;set;}

        public string Description {get;set;}

        public string Duration{get;set;}

        public string Commencement{get;set;}
        
    }
}