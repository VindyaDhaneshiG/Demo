using System;  
using System.Collections.Generic;  
using System.ComponentModel.DataAnnotations;  
using System.Linq;  
using System.Threading.Tasks;  

namespace newApi.Models
{
    public class Enroll
    {
          [Key]
       
        public int EnrollmentID{get;set;}

        public string Description {get;set;}

        public string EDate {get;set;}

        public string Fee {get;set;}

        public string User{get;set;}
        
    }
}