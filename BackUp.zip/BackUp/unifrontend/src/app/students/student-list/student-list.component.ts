import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/shared/student.service';
import { Student } from 'src/app/shared/student.model';
@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  alldatas: object;
  constructor(private service :StudentService) { }
 // ,private toster: ToastrService
  ngOnInit() {
    //this.service.refreshList();
      this.service.getStudent().subscribe(res=> {
      this.alldatas = res;
      console.log(this.alldatas);
      
       });

  }
  populateForm(stu:Student){
    this.service.formData = Object.assign({},stu);
 }

 onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.service.deleteStudent(id).subscribe(res=>{
     this.service.refreshList();

      // this.toster.warning('Deleted Sucessfully','EMP Register')
   });}
 }

 EditTableRow(rowID){
console.log(rowID);
return rowID;
 }
}

