import { Component, OnInit } from '@angular/core';
import { EnrollService } from 'src/app/shared/enroll.service';
import { Enroll } from 'src/app/shared/enroll.model';
@Component({
  selector: 'app-enrollment-list',
  templateUrl: './enrollment-list.component.html',
  styleUrls: ['./enrollment-list.component.css']
})
export class EnrollmentListComponent implements OnInit {

  constructor(private service :EnrollService) { 
     // ,private toster: ToastrService
  }

  ngOnInit() {
    this.service.refreshList();
  }
  populateForm(enr:Enroll){
    this.service.formData = Object.assign({},enr);

 }

 onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.service.deleteEnroll(id).subscribe(res=>{
     this.service.refreshList();
      // this.toster.warning('Deleted Sucessfully','EMP Register')
   });}
 }

}
