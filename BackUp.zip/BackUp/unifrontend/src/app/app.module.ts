import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule,routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgForm } from '@angular/forms';
import { FormsModule }   from '@angular/forms';
import { StudentComponent } from './students/student/student.component';
import { StudentListComponent } from './students/student-list/student-list.component';
import { LecturerListComponent } from './lecturers/lecturer-list/lecturer-list.component';
import { LecturerComponent } from './lecturers/lecturer/lecturer.component';
import { CourseComponent } from './courses/course/course.component';
import { CourseListComponent } from './courses/course-list/course-list.component';
import { EnrollmentListComponent } from './enrollments/enrollment-list/enrollment-list.component';
import { EnrollmentComponent } from './enrollments/enrollment/enrollment.component';
import {HttpClientModule } from "@angular/common/http";
import { HomeComponent } from './home/home.component';
import { StudentsComponent } from './students/students.component';
import { LecturersComponent } from './lecturers/lecturers.component';
import { CoursesComponent } from './courses/courses.component';
import { EnrollmentsComponent } from './enrollments/enrollments.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    StudentListComponent,
    LecturerListComponent,
    LecturerComponent,
    CourseComponent,
    CourseListComponent,
    EnrollmentListComponent,
    EnrollmentComponent,
    HomeComponent,
    routingComponents,
    StudentsComponent,
    LecturersComponent,
    CoursesComponent,
    EnrollmentsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
