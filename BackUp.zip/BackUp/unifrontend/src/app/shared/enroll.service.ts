import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Enroll } from './enroll.model';
@Injectable({
  providedIn: 'root'
})
export class EnrollService {
  formData : Enroll;
  list : Enroll[];
  readonly rootURL="https://localhost:5001/api/"
  constructor(private http:HttpClient) { }
  postEnroll( formData : Enroll){
    return this.http.post(this.rootURL+'/Enroll',formData)
  }
  
  refreshList(){
  this.http.get(this.rootURL+'/Enroll')
  .toPromise().then(res => this.list = res as Enroll[]);
  }
  
  putEnroll(formData:Enroll){
  return this.http.put(this.rootURL+'/Enroll/'+formData.EnrollmentID,formData);
  }
  deleteEnroll(id : number)
  {
  return this.http.delete(this.rootURL+'/Enroll/'+id);
  }
}
