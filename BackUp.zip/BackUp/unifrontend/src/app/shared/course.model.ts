export class Course {
        CourseID:number;
        CourseName:string;
        Description:string;
        Duration:string;
        Commencement:string;
}
