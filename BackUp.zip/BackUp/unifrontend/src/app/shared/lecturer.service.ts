import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Lecturer } from './lecturer.model';
@Injectable({
  providedIn: 'root'
})
export class LecturerService {
  formData : Lecturer;
  list : Lecturer[];
  readonly rootURL="https://localhost:5001/api"
  constructor(private http:HttpClient) { }

  postLecturer( formData : Lecturer){
    return this.http.post(this.rootURL+'/lecturer',formData)
  }
 
  refreshList(){
  this.http.get(this.rootURL+'/lecturer')
  .toPromise().then(res => this.list = res as Lecturer[]);
  console.log(this.list)
  }
 
  
  putLecturer(formData:Lecturer){
  return this.http.put(this.rootURL+'/lecturer/'+formData.LecturerID,formData);
  }

  deleteLecturer(id : number)
  {
  return this.http.delete(this.rootURL+'/lecturer/'+id);
  }


  getLecturer(){
    return this.http.get(this.rootURL+'/lecturer');
  }

 
}
