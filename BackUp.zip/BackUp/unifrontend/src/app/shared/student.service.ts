import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Student } from './student.model';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  formData : Student;
  list : Student[];
  readonly rootURL="https://localhost:5001/api"
  constructor(private http:HttpClient) { }

postStudent( formData : Student){
  return this.http.post(this.rootURL+'/student',formData)
}

refreshList(){
this.http.get(this.rootURL+"/Student")
.toPromise()
.then(res => {this.list = res as Student[];
  console.log(this.list)
});
}

putStudent(formData:Student){
return this.http.put(this.rootURL+'/student/'+formData.StudentID,formData);
}
deleteStudent(id : number)
{
return this.http.delete(this.rootURL+'/student/'+id);
}
getStudent(){
  return this.http.get(this.rootURL+'/student');
}
// putCourse() {
//   return this.http.put(
//   this.rootURL + "/student/" + this.formData.StudentID,
//   this.formData
//   );
//   }


}

