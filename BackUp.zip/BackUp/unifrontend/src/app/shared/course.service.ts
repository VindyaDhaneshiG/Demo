import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Course } from './course.model';
@Injectable({
  providedIn: 'root'
})
export class CourseService {
  formData : Course;
  list : Course[];
  readonly rootURL="https://localhost:5001/api/"
  constructor(private http:HttpClient) { }

  postCourse( formData : Course){
    return this.http.post(this.rootURL+'/Course',formData)
  }
  
  refreshList(){
  this.http.get(this.rootURL+'/Course')
  .toPromise().then(res => this.list = res as Course[]);
  }
  
  putCourse(formData:Course){
  return this.http.put(this.rootURL+'/Course/'+formData.CourseID,formData);
  }
  deleteCourse(id : number)
  {
  return this.http.delete(this.rootURL+'/Course/'+id);
  }
  }

