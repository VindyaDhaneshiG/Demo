import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Lecturer } from './lecturer.model';
@Injectable({
  providedIn: 'root'
})
export class LecturerService {
  formData : Lecturer;
  list : Lecturer[];
  readonly rootURL="http://localhost:7741/api"
  constructor(private http:HttpClient) { }

  postLecturer( formData : Lecturer){
    return this.http.post(this.rootURL+'/Student',formData)
  }
  
  refreshList(){
  this.http.get(this.rootURL+'/Lecturer')
  .toPromise().then(res => this.list = res as Lecturer[]);
  }
  
  putLecturer(formData:Lecturer){
  return this.http.put(this.rootURL+'/Lecturer/'+formData.LecturerID,formData);
  }
  deleteLecturer(id : number)
  {
  return this.http.delete(this.rootURL+'/Lecturer/'+id);
  }
}
