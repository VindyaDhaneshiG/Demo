import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Student } from './student.model';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  formData : Student;
  list : Student[];
  readonly rootURL="http://localhost:7741/api"
  constructor(private http:HttpClient) { }

postStudent( formData : Student){
  return this.http.post(this.rootURL+'/Student',formData)
}

refreshList(){
this.http.get(this.rootURL+'/Student')
.toPromise().then(res => this.list = res as Student[]);
}

putStudent(formData:Student){
return this.http.put(this.rootURL+'/Student/'+formData.StudentID,formData);
}
deleteStudent(id : number)
{
return this.http.delete(this.rootURL+'/Student/'+id);
}
}