export class Student {
    
        StudentID:number;
        FullName:string;
        Gender:string;
        Mobile:string;
        Email:string;
      
}
