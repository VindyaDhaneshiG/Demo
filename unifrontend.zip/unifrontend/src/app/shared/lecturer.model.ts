export class Lecturer {
        LecturerID:number;
        FullName:string;
        Gender:string;
        Mobile:string;
        Email:string;
}
