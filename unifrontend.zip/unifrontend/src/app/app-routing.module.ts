import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentComponent } from './students/student/student.component';
import { LecturerComponent } from 'src/app/lecturers/lecturer/lecturer.component';
import { CourseComponent } from 'src/app/courses/course/course.component';
import { EnrollmentComponent } from 'src/app/enrollments/enrollment/enrollment.component';
import { HomeComponent } from 'src/app/home/home.component';

const routes: Routes = [{ path: 'home', component: HomeComponent },{ path: 'student', component: StudentComponent },
{ path: 'lecturer',      component: LecturerComponent },{ path: 'course', component: CourseComponent },
{ path: 'enroll',      component: EnrollmentComponent },{ path: '**', component: HomeComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[HomeComponent,StudentComponent,LecturerComponent,CourseComponent,EnrollmentComponent]