import { Component, OnInit } from '@angular/core';
import { CourseService } from 'src/app/shared/course.service';
import { Course } from 'src/app/shared/course.model';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  constructor(private service :CourseService) {
    // ,private toster: ToastrService
   }

  ngOnInit() {
    this.service.refreshList();
  }
  populateForm(crs:Course){
    this.service.formData = Object.assign({},crs);

 }
 onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.service.deleteCourse(id).subscribe(res=>{
     this.service.refreshList();
      // this.toster.warning('Deleted Sucessfully','EMP Register')
   });}
 }
}
