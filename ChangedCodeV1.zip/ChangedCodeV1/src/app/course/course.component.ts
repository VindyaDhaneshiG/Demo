import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Course } from '../course.model';
@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  @Input()  cleardata: boolean = false;
  @Output() nameEvent = new EventEmitter<string>();
  objtcrscrs:Course;
  @Input() objcrs :Course=new Course();;
  // @ViewChild('closeBtn') cb: ElementRef;
  //course : {id,cname, cduration,coursetype,faculty,prerequisites} = {id :null, cname:" ", cduration :" ",coursetype:" ",faculty:" ",prerequisites:" "};

  constructor(private service: CourseService,private toastr: ToastrService) { }


  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        CourseID: null,
        CourseName:'',
        CourseDuration:'',
        CourseType:'',
        FacultyOffer:'',
        CoursePrerequisites:''
       }
       }

       onSubmit(form : NgForm) {
        // if(form.value.LecturerID==null)
        this.insertRecord(form);
        // else
        // this.updateRecord(form);
      }

      insertRecord(form : NgForm){
        this.service.postCourse(form.value).subscribe(res=> {
        this.toastr.success('Inserted Sucessfully','Swinburne Register')
       this.resetForm(form);
       this.service.refreshList();
        });
       }

       Register(crsadd:NgForm){  
   
        this.objtcrscrs=new Course();
        this.objtcrscrs.CourseName=crsadd.value.courseName;
        this.objtcrscrs.CourseDuration=crsadd.value.courseDuration;
        this.objtcrscrs.CourseType=crsadd.value.courseType;
        this.objtcrscrs.FacultyOffer=crsadd.value.facultyOffer;
        this.objtcrscrs.CoursePrerequisites=crsadd.value.coursePrerequisites;


        
      this.service.AddCourse(this.objtcrscrs).subscribe(res=>{
        alert("Course Added successfully");
        // this.TakeHome();
        // this.lecadd.objtleclec.FirstName = ""
    }
  )}


  updateRecord(form:NgForm){
    this.service.putCourse(form.value).subscribe(res=> {
      this.toastr.warning('Updated Sucessfully','Swinburn Register')
      this.resetForm(form);
      this.service.refreshList();
       });
  
  }

}
