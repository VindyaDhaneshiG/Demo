import { Component, OnInit, ViewChild, Input, EventEmitter, Output, ElementRef } from '@angular/core';
import { LecturerService } from 'src/app/lecturer.service';
import { Lecturer } from 'src/app/lecturer.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { LecturerComponent } from 'src/app/lecturer/lecturer.component';
import { NgForm, Form } from '@angular/forms';
@Component({
  selector: 'app-updatelecturer',
  templateUrl: './updatelecturer.component.html',
  styleUrls: ['./updatelecturer.component.css']
})
export class UpdatelecturerComponent implements OnInit {

  constructor(private lecturerService: LecturerService, private route: Router, private toastr: ToastrService) { }
  @Output() nameEvent = new EventEmitter<string>();
  @Input() reset = false;
  // @ViewChild('Lecedit') myForm: NgForm;
  @Input() isReset = false;
  objtleclec: Lecturer;
  @Input() objemp: Lecturer = new Lecturer();
  // @ViewChild('closeBtn') cb: ElementRef;
  ngOnInit() {
  }


  //
  // onDelete(id:number)
  // {
  //   if(confirm("Are you sure to delete this record?")){
  //   this.lecturerService.deleteLecturer(id).subscribe(res=>{
  //     this.lecturerService.refreshList();
  //       this.toastr.warning('Deleted Sucessfully','Swinburne University')
  //   });}
  //
  onEdit(Lecedit: NgForm) {
    if (confirm('Are you sure to update this record?')) {
      this.lecturerService.putLecturer(Lecedit.value).subscribe(res => {
        this.lecturerService.refreshList();
        this.toastr.warning('Updated Sucessfully', 'Swinburne University');
      });
    }
  }




}
