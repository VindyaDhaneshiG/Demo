import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from '../models/student.model';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  formData: Student;
  list: Student[];
  private readonly apiPathStudent = '/student';
  private readonly urlDetails = `${environment.studentApiUrl}${this.apiPathStudent}`;
  students: Observable<Student[]>;
  newlecturer: Student;

  // students = [
  //   {id: 1, fname: "Saman",lname:"Perera" , dob: "10-03-1990",email:"sam@gmail.com", gender: "Male",address:"No 5 Temple Road Colombo"},
  //   {id: 2, fname: "Nimal",lname:"Silva" , dob: "20-05-1995",email:"nim@gmail.com", gender: "Male",address:"No 7 Flowers Road Colombo"},
  //   {id: 3, fname: "Kusum",lname:"Senarathna" , dob: "17-04-1992",
  // email:"kus@gmail.com", gender: "Female",address:"No 15 StAnthoney Road Kadana"},
  //   {id: 4, fname: "Ruwan",lname:"Gunasekara" , dob: "22-03-1990",
  // email:"run@gmail.com", gender: "Male",address:"No 5 Temple Road Colombo"}
  // ];
  // public getStudents():Array<{id,fname, lname,dob,email,gender, address}>{
  //   return this.students;
  // }
  // public createStudent(contact: {id,fname, lname,dob,email,gender, address}){
  //   this.students.push(contact);
  // }
  // ----
  constructor(private http: HttpClient) { }

  postStudent(formData: Student) {
    return this.http.post(this.urlDetails, formData);
  }

  refreshList() {
    this.http.get(this.urlDetails)
      .toPromise().then(res => { this.list = res as Student[]; });
    console.log(this.list);
  }

  putStudent(formData: Student) {

    // return this.http.put(this.rootURL + '/student/' + formData.StudentID, formData);
  }
  deleteStudent(id: number) {
    // return this.http.delete(this.rootURL + '/student/' + id);
  }
  getStudentList() {
    return this.http.get(this.urlDetails);
  }

  getLecturer2() {
    // return this.http.get<Student[]>(this.rootURL + 'Lecturers');
  }

  AddStudent(stu: Student) {

    const headers = new HttpHeaders().set('content-type', 'application/json');
    const body = {
      FirstName: stu.FirstName, LastName: stu.LastName, DateofBirth: stu.DateofBirth, ContactEmail: stu.ContactEmail, Gender: stu.Gender,
      ContactAddress: stu.ContactAddress
    };
    // return this.http.post<Student>(this.rootURL + '/student', body, { headers });

  }


  // //get a particular student
  GetStudent(id: number) {

    return this.http.get(`${this.urlDetails}/${id}`);
  }


  // editStudentRow(data){
  //   console.log(data);
  //   return data;
  // }
}
