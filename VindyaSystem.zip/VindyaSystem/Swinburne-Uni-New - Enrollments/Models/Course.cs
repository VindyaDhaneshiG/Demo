using System;  
using System.Collections.Generic;  
using System.ComponentModel.DataAnnotations;  
using System.Linq;  
using System.Threading.Tasks;  
using System.ComponentModel.DataAnnotations.Schema;
namespace Swinburne_Uni_New.Models
{
    public class Course
    {
      [Key]
    public int CourseID {get;set;}
    [Column(TypeName = "varchar(20)")]
        [Required]
        public string CourseName {get;set;}
    
    public string CourseDuration{get;set;}
    public string CourseType{get;set;}
    public string FacultyOffer{get;set;}
    public string CoursePrerequisites{get;set;}
    public virtual ICollection<Enrollment> Enrollments { get; set; }
   
    }
}
