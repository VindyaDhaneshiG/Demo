export class Enrlist {
   
    FirstName:string;
    CourseName:string;
    EnrollmentID:number;
    
    
}
