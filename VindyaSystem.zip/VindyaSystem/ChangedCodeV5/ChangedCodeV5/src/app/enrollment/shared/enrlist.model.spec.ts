import { Enrlist } from './enrlist.model';

describe('Enrlist', () => {
  it('should create an instance', () => {
    expect(new Enrlist()).toBeTruthy();
  });
});
