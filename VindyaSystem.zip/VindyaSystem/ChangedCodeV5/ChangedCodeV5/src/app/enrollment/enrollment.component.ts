import { Component, OnInit } from '@angular/core';
import { EnrollmentService } from '../enrollment.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Enrollment } from '../enrollment.model';
import { Course } from 'src/app/course/shared/models/course.model';
import { Student } from '../shared/models/student.model';

@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css']
})
export class EnrollmentComponent implements OnInit {
  @Input()  cleardata: boolean = false;
  @Output() nameEvent = new EventEmitter<string>();
  objtenrenr:Enrollment;
  @Input() objenr :Enrollment=new Enrollment();
  // @ViewChild('closeBtn') cb: ElementRef;
  // lecturer : {eid,edate, sid,sname,cid,cname,estatus,cfee, installments,installmentspay} = {eid :null, edate:"", sid :" ",sname:" ",cid:" ", cname:"",estatus:" ",cfee:" ", installments:" ",installmentspay:" "};
  constructor(private service: EnrollmentService,private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
   
    this.service.GetStudentList();
    this.service.GetCourseList();
  }

  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        EnrollmentID: null,
        EnrollmentDate:'',
        StudentID: null,
        StudentName:'',
        CourseID: null,
        CourseName:'',
        EnrollmentStatus:'',
        CourseFee: null,
        Installments:'',
        InstallmentPaymentAmount: null
        

       }

       }
       onSubmit(form: NgForm) {
        if (this.service.formData1.EnrollmentID == 0) this.insertRecord(form);
        else this.updateRecord(form);
      }
    
      insertRecord(form: NgForm) {
        this.service.PostEnrollment().subscribe(
          res => {
            debugger;
            this.resetForm(form);
            this.toastr.success(
              "Submitted successfully",
              "Enrollment Register"
            );
            this.service.refreshList1();
          },
          err => {
            debugger;
            console.log(err);
          }
        );
      }

      updateRecord(form: NgForm) {
        this.service.PutEnrollment().subscribe(
          res => {
            this.resetForm(form);
            this.toastr.info("Submitted successfully", "Enrollment Register");
            this.service.refreshList1();
          },
          err => {
            console.log(err);
          }
        );
      }
       Register(enradd:NgForm){  
   
        this.objtenrenr=new Enrollment();
        this.objtenrenr.EnrollmentDate=enradd.value.enrollmentDate;
        this.objtenrenr.StudentID=enradd.value.studentID;
        this.objtenrenr.StudentName=enradd.value.studentName;
        this.objtenrenr.CourseID=enradd.value.courseID;
        this.objtenrenr.CourseName=enradd.value.courseName;
        this.objtenrenr.EnrollmentStatus=enradd.value.enrollmentStatus;
        this.objtenrenr.CourseFee=enradd.value.courseFee;
        this.objtenrenr.Installments=enradd.value.installments;
        this.objtenrenr.InstallmentPaymentAmount=enradd.value.InstallmentPaymentAmount;
        

        
      this.service.AddEnrollment(this.objtenrenr).subscribe(res=>{
        alert("Enrollment Added successfully");
        // this.TakeHome();
        // this.lecadd.objtleclec.FirstName = ""
    }
  )}

  updateRecord(form:NgForm){
    this.service.postEnrollments(form.value).subscribe(res=> {
      this.toastr.warning('Updated Sucessfully','Swinburn Register')
      this.resetForm(form);
      this.service.refreshList();
       });
  
  }

}
