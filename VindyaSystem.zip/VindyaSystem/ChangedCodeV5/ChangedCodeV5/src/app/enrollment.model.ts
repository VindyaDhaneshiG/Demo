export class Enrollment {
EnrollmentID:number;
EnrollmentDate:string;
StudentID:number;
StudentName:string;
CourseID:number;
CourseName:string;
EnrollmentStatus:string;
CourseFee:number;
Installments:string;
InstallmentPaymentAmount:number;

}
