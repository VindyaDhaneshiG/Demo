import {Component} from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: 'src/navbar.html'
})
export class navbar {
  isNavbarCollapsed=true;
}
