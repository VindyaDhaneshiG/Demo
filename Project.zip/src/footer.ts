import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-footer',
  templateUrl: 'src/footer.html',
  styleUrls: ['src/footer.css']
})
export class footer implements OnInit {
}