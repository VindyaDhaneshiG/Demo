using Swinburne_Uni_New.Models;
using System;
using System.Collections.Generic;
using Swinburne_Uni_New.Contracts;
using Swinburne_Uni_New.ViewModel;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Swinburne_Uni_New.Services
{
    public class SchServices : ISchServices
    {
        SchDbContext db;

        public SchServices(SchDbContext _db)
        {
            db = _db;
        }

         public async Task<int> Add (Course newItem)
        {
           if (db != null)
            {
                await db.Courses.AddAsync(newItem);
                await db.SaveChangesAsync();

                return newItem.CourseID;
            }

            return 0;
        }

        public async Task<List<CourseViewModel>>  GetAllCourses()
        {
           if (db != null)
            {
                return await (from c in db.Courses
                              
                              select new CourseViewModel
                              {
                                  CourseID = c.CourseID,
                                  CourseName = c.CourseName,
                                  StartDate = c.StartDate,
                                  EndDate = c.EndDate
                              }).ToListAsync();
            }

            return null;
        }

        public async Task<CourseViewModel> GetById(int? courseId)
        {
            if (db != null){

                    return await (from c in db.Courses
                              
                              where c.CourseID == courseId
                              select new CourseViewModel
                              {
                                  CourseID = c.CourseID,
                                  CourseName = c.CourseName,
                                  StartDate = c.StartDate,
                                  EndDate = c.EndDate
                              }).FirstOrDefaultAsync();
                }


           return null;
        }

        public async Task<int>  Remove(int? id)
        {
            int result = 0;

            if (db != null)
            {
                //Find the post for specific post id
                var course = await db.Courses.FirstOrDefaultAsync(x => x.CourseID == id);

                if (course != null)
                {
                    //Delete that post
                    db.Courses.Remove(course);

                    //Commit the transaction
                    result = await db.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }

         public async Task UpdateCourse(Course course)
        {
            if (db != null)
            {
                //Delete that post
                db.Courses.Update(course);

                //Commit the transaction
                await db.SaveChangesAsync();
            }
        }
        
    }
}