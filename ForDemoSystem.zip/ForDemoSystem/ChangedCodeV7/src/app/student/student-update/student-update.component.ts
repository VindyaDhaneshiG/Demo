import { Component, OnInit } from '@angular/core';
import { StudentService } from '../shared/services/student.service';
import { NgForm, FormGroup, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Input, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import { Student } from '../shared/models/student.model';
import { FormBuilder, FormArray, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Enrollment } from 'src/app/enrollment/shared/models/enrollment.model';
import { EnrollmentService } from 'src/app/enrollment/shared/services/enrollment.service';
import { Course } from 'src/app/course/shared/models/course.model';
import { CourseService } from 'src/app/course/shared/services/course.service';
// import { ValidatePassword } from "./must-match/validate-password";
@Component({
  selector: 'app-student-update',
  templateUrl: './student-update.component.html',
  styleUrls: ['./student-update.component.css']
})

export class StudentUpdateComponent implements OnInit {

  constructor(private service: StudentService,
    private toastr: ToastrService,
    private router: Router, private activatedRoute: ActivatedRoute) { }
  @Input() cleardata = false;
  @Output() nameEvent = new EventEmitter<string>();
  studentForm: FormGroup;

  editButtonName: boolean;
  submitButtonName: boolean;
  studentIdNumber: number;

  ngOnInit() {
    this.formLoad();
  }

  formLoad() {

    this.activatedRoute.queryParams.subscribe((params: any) => {

      if (params.id) {
        this.studentIdNumber = Number.parseInt(params.id, 10);
      }
    });
    this.studentForm = new FormGroup({
      studentID: new FormControl('', [Validators.required]),
      firstName: new FormControl('',
        [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]),
      lastName: new FormControl('',
        [Validators.required, Validators.minLength(2), Validators.pattern('^[_A-z0-9]*((-|\s)*[_A-z0-9])*$')]),
      dateofBirth: new FormControl('', [Validators.required]),
      contactEmail: new FormControl('', [Validators.required, Validators.email]),
      gender: new FormControl('', [Validators.required]),
      contactAddress: new FormControl('', [Validators.required, Validators.minLength(2)]),

    });


    this.studentForm.reset();

    this.getRecord(this.studentIdNumber);
    this.studentForm.disable();
    this.editButtonName = false;
    this.submitButtonName = true;
  }
  formControls() { return this.studentForm.controls; }

  reset() {
    this.formLoad();
  }

  enableUpdate() {
    this.studentForm.enable();
    this.editButtonName = true;
    this.submitButtonName = false;
  }


  onSubmit() {
    const student = this.Register();

    this.service.putStudent(student).subscribe(res => {
      // Todo: Needs to update on the toast message
      this.toastr.success('Updated Sucessfully', 'Swinburne Register');
      this.formLoad();
    });
  }

  getRecord(id: number) {
    this.service.GetStudent(id).subscribe(res => {
      this.studentForm.patchValue(res);
    });
  }

  Register(): Student {
    const student = new Student();
    student.StudentID = this.studentForm.value.studentID;
    student.FirstName = this.studentForm.value.firstName;
    student.LastName = this.studentForm.value.lastName;
    student.DateofBirth = this.studentForm.value.dateofBirth;
    student.ContactEmail = this.studentForm.value.contactEmail;
    student.Gender = this.studentForm.value.gender;
    student.ContactAddress = this.studentForm.value.contactAddress;

    return student;
  }

  delete() {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteStudent(this.studentIdNumber).subscribe(res => {
        this.router.navigate([`students`]);
      });
    }
  }

  enroll() {
    this.router.navigate(['/enroll/student'], { queryParams: { id: this.studentIdNumber } });
  }

}
