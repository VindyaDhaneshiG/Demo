import { Component, OnInit, ViewChild } from '@angular/core';
import { CourseService } from './shared/services/course.service';
import { Course } from 'src/app/course/shared/models/course.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';


@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  courseList: object;

  constructor(public service: CourseService, private toastr: ToastrService, private route: Router) { }

  ngOnInit() {
    this.service.getCourseList().subscribe(response => {
      this.courseList = response;
    });

  }

  loadView(courseId: any) {
    //console.log(courseId);
    this.route.navigate(['courses/update'], { queryParams: { id: courseId } });
  }

}
