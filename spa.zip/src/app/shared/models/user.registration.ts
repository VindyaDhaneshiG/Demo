export class UserRegistration {

    constructor(
        public name: string,
        public email: string,
        public password: string            
      ) {  }
}
