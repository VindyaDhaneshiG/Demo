﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SwinburneUniNew.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Courses",
                columns: table => new
                {
                    CourseID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CourseName = table.Column<string>(nullable: true),
                    CourseDuration = table.Column<string>(nullable: true),
                    CourseType = table.Column<string>(nullable: true),
                    FacultyOffer = table.Column<string>(nullable: true),
                    CoursePrerequisites = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Courses", x => x.CourseID);
                });

            migrationBuilder.CreateTable(
                name: "Enrollments",
                columns: table => new
                {
                    EnrollmentID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    EnrollmentDate = table.Column<string>(nullable: true),
                    StudentID = table.Column<int>(nullable: false),
                    StudentName = table.Column<string>(nullable: true),
                    CourseID = table.Column<int>(nullable: false),
                    CourseName = table.Column<string>(nullable: true),
                    EnrollmentStatus = table.Column<string>(nullable: true),
                    CourseFee = table.Column<int>(nullable: false),
                    Installments = table.Column<string>(nullable: true),
                    InstallmentPaymentAmount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Enrollments", x => x.EnrollmentID);
                });

            migrationBuilder.CreateTable(
                name: "Lecturers",
                columns: table => new
                {
                    LecturerID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    DateofBirth = table.Column<string>(nullable: true),
                    DateofJoin = table.Column<string>(nullable: true),
                    ContactEmail = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    ContactAddress = table.Column<string>(nullable: true),
                    LecturerCategory = table.Column<string>(nullable: true),
                    LecturerContract = table.Column<string>(nullable: true),
                    LecturerQualification = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Lecturers", x => x.LecturerID);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    DateofBirth = table.Column<string>(nullable: true),
                    ContactEmail = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    ContactAddress = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Courses");

            migrationBuilder.DropTable(
                name: "Enrollments");

            migrationBuilder.DropTable(
                name: "Lecturers");

            migrationBuilder.DropTable(
                name: "Students");
        }
    }
}
