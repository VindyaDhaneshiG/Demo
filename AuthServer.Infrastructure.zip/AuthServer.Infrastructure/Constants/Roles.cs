﻿

namespace AuthServer.Infrastructure.Constants
{
    public static class Roles
    {
        public const string Consumer = "consumer";
    }
}
