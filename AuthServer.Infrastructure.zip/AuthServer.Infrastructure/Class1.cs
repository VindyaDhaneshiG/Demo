﻿using System;

namespace AuthServer.Infrastructure
{
    public class Class1
    {
    }
}
